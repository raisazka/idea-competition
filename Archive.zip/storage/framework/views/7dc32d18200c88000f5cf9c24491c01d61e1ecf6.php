<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/app.css">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="css/regis.css">
</head>
<body>
    <img src="image/wave_atas.png" class="wave wave_atas">
    <div class="form-form-form">
            <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
        <div class="content-promosi text-center container">
            <img src="image/BIC.png" alt="bic" class="img-fluid bic-logo">
            <h1>With</h1>
            <img src="image/tiket.png" alt="">
            <h3>BNCC Idea Competition</h3>
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="container-fluid form-container" id="grup">
            <div class="row">
                <div class="container-fluid gambar-input col-lg-4 col-md-4 col-sm-12 col-xs-12 "> <img src="image/team.png" class="img-fluid" alt="hello"> </div>
                <div class="container input-container col-lg-8 col-md-8 col-sm-12 col-xs-12 order-sm-first order-xs-first">
                    <h1>Grup</h1>
                    <div class="row">
                        <div class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                            <label for="Group">Group Name</label>
                            <input disabled style="border-radius:0; border:none;font-weight:900;font-size:1.5em;padding:6px 0;" type="text" class="form-control" id="Group" name="name" value="<?php echo e($user->name); ?>" autocomplete="name" placeholder="Group Name" required autofocus>
                        </div>
                        <div class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                            <label for="username">Username</label>
                            <input disabled style="border-radius:0; border:none;font-weight:900;font-size:1.5em;padding:6px 0;" type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username); ?>" placeholder="Username" autocomplete="username" required autofocus >
                        </div>
                    </div>
                    <div class="row d-md-flex d-lg-flex align-items-md-center align-items-lg-center">
                        <div class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                            <label for="Group">Payment status</label><br>
                            <span class="text-danger" style="border-radius:0; border:none;font-weight:900;font-size:1em;padding:6px 0;" >You have not paid please proceed payment before 20 june 2019</span>
                        </div>
                        <div class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                            <a href="<?php echo e(route('payment.index')); ?>" class="anti-a"> <button class="button-payment">Pay Now</button></a>
                        </div>
                    </div>
                    <div class="row d-md-flex d-lg-flex align-items-md-center align-items-lg-center">
                        <div class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                            <label for="Group">Proposal Tempalte</label><br>
                            <span style="border-radius:0; border:none;font-weight:900;font-size:1em;padding:6px 0;" >Template yang harus dipakai dalam pegerjaan case BIC</span>
                        </div>
                        <div class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                            <a href="<?php echo e(route('proposal.download')); ?>" class="anti-a"> <button class="button-payment">Download Now</button></a>
                        </div>
                    </div>
                    <form action="<?php echo e(route('proposal.upload')); ?>" enctype="multipart/form-data" method="POST" class="row d-md-flex d-lg-flex align-items-md-center align-items-lg-center">
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                            <label for="Group">Submit Proposal</label><br>
                            <input type="file" accept=".pdf,.png,.jpg,.PDF,.PNG,.JPG,.JPEG,.jpeg" id="proposal" class=" <?php if ($errors->has('proposal')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('proposal'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  name="proposal" style="border:none; padding:auto 0;" required autofocus>
                            <br>
                            <span class="cv_wrong" style="color:red; font-weight:700; font-size: .8em">
                                <?php if($errors->has('proposal')): ?>
                                    <?php echo e($errors->first('proposal')); ?>

                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="form-group col-md-6 col-lg-6 col-sm-12 col-xs-12">
                            <button class="button-payment" type="button" id="btn-proposal">Submit Proposal</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php $__currentLoopData = $user->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($loop->first): ?>
            <div class="container-fluid form-container">
                <div class="row">
                    <div class="container-fluid gambar-input col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <img src="image/ketua.png" class="img-fluid" alt="hello">
                    </div>
                    <div class="container input-container col-lg-8 col-md-8 col-sm-12 col-xs-12 ">        
                        <h2 class="container">Leader</h2>
        <?php elseif($loop->index == 1): ?>
            <div id="member1" class="container-fluid form-container">
                <div class="row">
                    <div class="container-fluid gambar-input col-lg-4 col-md-4 col-sm-12 col-xs-12 "> 
                        <img src="image/member1.png" class="img-fluid" alt="hello"> 
                    </div>
                    <div class="container input-container col-lg-8 col-md-8 col-sm-12 col-xs-12 order-sm-first order-xs-first">
                        <h2 class="container">Member 1</h2>
        <?php else: ?>
            <div id="member2" class="container-fluid form-container">
                <div class="row">
                    <div class="container-fluid gambar-input col-lg-4 col-md-4 col-sm-12 col-xs-12"> 
                        <img src="image/member2.png" class="img-fluid" alt="hello"> 
                    </div>
                    <div class="container input-container col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <h2 class="container">Member2</h2>
        <?php endif; ?>
                    <form action="<?php echo e(route('member.update', $member->id)); ?>" enctype="multipart/form-data" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="row">
                            <div class="form-group col-md-4 col-lg-4 col-sm-12 col-xs-12">
                                <label <?php if($loop->first): ?>for="name" <?php elseif($loop->index ==1): ?>for="name1" <?php else: ?> for="name2" <?php endif; ?>>Full Name</label>
                                <input type="text" style="border-radius:0; border:none; font-weight:900; padding:6px 0;" class="form-control <?php if ($errors->has('member_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('member_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e($member->member_name); ?>" autocomplete="member_name" name="member_name" <?php if($loop->first): ?>id="name" <?php elseif($loop->index ==1): ?>id="name1" <?php else: ?> id="name2" <?php endif; ?>  placeholder="Full Name" required autofocus disabled>
                            </div>
                            <div class="form-group col-md-4 col-lg-4 col-sm-12 col-xs-12">
                                <label <?php if($loop->first): ?>for="dob" <?php elseif($loop->index ==1): ?>for="dob1" <?php else: ?> for="dob2" <?php endif; ?>>Date Of Birth</label>
                                <input type="date" disabled style="border-radius:0; border:none; font-weight:900; padding:6px 0;" min="1997-01-01" max="2002-01-01" name="dob" value="<?php echo e($member->dob); ?>" class="form-control  <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" <?php if($loop->first): ?>id="dob" <?php elseif($loop->index ==1): ?>id="dob1" <?php else: ?> id="dob2" <?php endif; ?> placeholder="Date Of Birth" required autofocus>
                            </div>
                            <div class="form-group col-md-4 col-lg-4 col-sm-12 col-xs-12">
                                <label <?php if($loop->first): ?>for="email" <?php elseif($loop->index ==1): ?>for="email1" <?php else: ?> for="email2" <?php endif; ?>>Email</label>
                                <input type="email" disabled style="border-radius:0; border:none; font-weight:900; padding:6px 0;" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" <?php if($loop->first): ?>id="email" <?php elseif($loop->index ==1): ?>id="email1" <?php else: ?> id="email2" <?php endif; ?> value="<?php echo e($member->email); ?>" aria-describedby="emailHelp" placeholder="Email Address" required autofocus>
                            </div>              
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4 col-lg-4 col-sm-12 col-xs-12">
                                <label <?php if($loop->first): ?>for="Line" <?php elseif($loop->index ==1): ?>for="Line1" <?php else: ?> for="Line2" <?php endif; ?>>Line Id</label>
                                <input type="text" class="form-control <?php if ($errors->has('line')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('line'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" <?php if($loop->first): ?>id="Line" <?php elseif($loop->index ==1): ?>id="Line1" <?php else: ?> id="Line2" <?php endif; ?> name="line" value="<?php echo e($member->line); ?>" placeholder="Line Id" required autofocus> 
                                <span class="line_wrong" style="color:red; font-weight:700; font-size: .8em">
                                    <?php if($errors->has('line')): ?>
                                        <?php echo e($errors->first('line')); ?>

                                    <?php endif; ?>
                                </span>
                            </div>
                            <div class="form-group col-md-4 col-lg-4 col-sm-12 col-xs-12">
                                <label <?php if($loop->first): ?>for="Whatsapp" <?php elseif($loop->index ==1): ?>for="Whatsapp1" <?php else: ?> for="Whatsapp2" <?php endif; ?>>Whatsapp Number</label>
                                <input type="text" class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" <?php if($loop->first): ?>id="Whatsapp" <?php elseif($loop->index ==1): ?>id="Whatsapp1" <?php else: ?> id="Whatsapp2" <?php endif; ?> value="<?php echo e($member->phone); ?>" autocomplete="phone" name="phone" placeholder="WhatsApp Number" required autofocus>
                                <span class="phone_wrong" style="color:red; font-weight:700; font-size: .8em">
                                    <?php if($errors->has('phone')): ?>
                                        <?php echo e($errors->first('phone')); ?>

                                    <?php endif; ?>
                                </span>
                            </div>
                            
                            <div class="form-group col-md-4 col-lg-4 col-sm-12 col-xs-12 form-ktp">
                                <label <?php if($loop->first): ?>for="cv" <?php elseif($loop->index ==1): ?>for="cv1" <?php else: ?> for="cv2" <?php endif; ?>>Curriculum Vitae</label>
                                <input type="file" accept=".pdf,.png,.jpg,.PDF,.PNG,.JPG,.JPEG,.jpeg" class="form-control <?php if ($errors->has('cv')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cv'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" <?php if($loop->first): ?>id="cv" <?php elseif($loop->index ==1): ?>id="cv1" <?php else: ?> id="cv2" <?php endif; ?> name="cv" required autofocus>
                                <span class="cv_wrong" style="color:red; font-weight:700; font-size: .8em">
                                    <?php if($errors->has('cv')): ?>
                                        <?php echo e($errors->first('cv')); ?>

                                    <?php endif; ?>
                                </span>
                            </div>  
                        </div>
                        <div class="row d-md-flex d-lg-flex align-items-md-center align-items-lg-center justify-content-md-end justify-content-lg-end">
                            <button class="btn-update " <?php if($loop->first): ?>id="btn-up" <?php elseif($loop->index ==1): ?>id="btn-up-1" <?php else: ?> id="btn-up-2" <?php endif; ?> type="button">Update Data</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <img src="image/wave_bawah.png" class="wave wave_bawah">
    <script src="js/app.js"></script>
    <script src="js/dashboard-home.js"></script>
</body>
</html><?php /**PATH /Users/raisazka/Documents/laravel-project/idea-competition/resources/views/Dashboard.blade.php ENDPATH**/ ?>