<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><strong>Admin's</strong> Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">No</th>
                            <th scope="col">Group Name</th>
                            <th scope="col">Name</th>
                            <th scope="col">E-Mail</th>
                            <th scope="col">Whatsapp</th>
                            <th scope="col">KTP</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($member->users->name); ?></td>
                            <td><?php echo e($member->member_name); ?></td>
                            <td><?php echo e($member->email); ?></td>
                            <td><?php echo e($member->phone); ?></td>
                            <td>
                                <a href="<?php echo e(asset('storage/ktp/'.$member->ktp)); ?>">
                                <img src="<?php echo e(asset('storage/ktp/'.$member->ktp)); ?>" alt="no-image" height="50" width="100">
                                </a>
                            </td>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
    <a href="<?php echo e(route('admin.dashboard')); ?>">View User Payment</a>
    <br>
    <a href="<?php echo e(route('admin.member')); ?>">View Members</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/raisazka/Documents/laravel-project/idea-competition/resources/views/admin/dashboard-2.blade.php ENDPATH**/ ?>