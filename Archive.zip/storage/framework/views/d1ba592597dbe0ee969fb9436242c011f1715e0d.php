<?php $__env->startSection('content'); ?>
<div class="container">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('user.register')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Username')); ?></label>

                            <div class="col-md-6">
                                <input id="username" type="text" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="email">

                                <?php if($errors->has('username')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>
                        <hr>
                        <h2>Members</h2>
                        <div id="holder">
        <div class="form-group row">
                <label for="member_name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                <div class="col-md-6">
                    <input id="member_name" type="text" class="form-control <?php if ($errors->has('member_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('member_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="member_name[]" value="<?php echo e(old('member_name')); ?>" required autocomplete="member_name" autofocus>

                    <?php if($errors->has('member_name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('member_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>

                    <div class="col-md-6">
                        <input id="email" type="text" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email[]" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                        <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                        <label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone')); ?></label>

                        <div class="col-md-6">
                            <input id="phone" type="text" class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="phone[]" value="<?php echo e(old('phone')); ?>" required autocomplete="phone" autofocus>

                            <?php if($errors->has('phone')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('phone')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                            <label for="line" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Line')); ?></label>

                            <div class="col-md-6">
                                <input id="line" type="text" class="form-control <?php if ($errors->has('line')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('line'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="line[]" value="<?php echo e(old('line')); ?>" required autocomplete="line" autofocus>

                                <?php if ($errors->has('line')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('line'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                                <label for="dob" class="col-md-4 col-form-label text-md-right"><?php echo e(__('DOB')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="dob" type="date" class="form-control <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="dob[]" value="<?php echo e(old('dob')); ?>" required autocomplete="dob" autofocus>
    
                                    <?php if ($errors->has('dob')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dob'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                                <label for="ktp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Upload KTP')); ?></label>
    
                                <div class="col-md-6">
                                    <input id="ktp" type="file" class="form-control <?php if ($errors->has('ktp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ktp'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="ktp[]" value="<?php echo e(old('ktp')); ?>" required autocomplete="ktp" autofocus>
    
                                    <?php if ($errors->has('ktp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('ktp'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group row mb-0">
                                <div class="col-md-4">
                                        <a id="add">Add Person</a>
                                    </div>
                                    <div class="col-md-6">
                                        <button type="submit" class="btn btn-primary">
                                            <?php echo e(__('Register')); ?>

                                        </button>
                                    </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
        var i = 1;
        
        $('#add').on('click', function(){
        i++;
        if(i <= 3){
        $('#holder').append(
            '<hr>' +
            '<div class="form-group row">' +
            '<label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>' +
            '<div class="col-md-6">' +
            '<input id="member_name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="member_name[]" value="<?php echo e(old('member_name')); ?>" required autocomplete="member_name" autofocus>'
            + '</div>' 
            + '</div>'
            + '<div class="form-group row">' +
            '<label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-mail')); ?></label>' +
            '<div class="col-md-6">' +
            '<input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email[]" value="<?php echo e(old('email')); ?>" required autocomplete="email">'
            + '</div>' 
            + '</div>' +
            '<div class="form-group row">' +
            '<label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone Number')); ?></label>' +
            '<div class="col-md-6">' +
            '<input id="phone" type="tel" class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('phone')); ?>" name="phone[]" required autocomplete="tel">'
            + '</div>' 
            + '</div>' +
            '<div class="form-group row">' +
            '<label for="line" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Line ID')); ?></label>' +
            '<div class="col-md-6">' +
            '<input id="line" type="text" class="form-control" name="line[]"  required autocomplete="line">'
            + '</div>' 
            + '</div>' +
            '<div class="form-group row">' +
            '<label for="dob" class="col-md-4 col-form-label text-md-right"><?php echo e(__('DOB')); ?></label>' +
            '<div class="col-md-6">' +
            '<input id="dob" type="date" class="form-control" name="dob[]"  required autocomplete="dob">'
            + '</div>' 
            + '</div>' +
            '<div class="form-group row">' +
            '<label for="ktp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Upload KTP')); ?></label>' +
            '<div class="col-md-6">' +
           '<input id="ktp" type="file" class="form-control" name="ktp[]"  required autocomplete="ktp">'
            + '</div>' 
            + '</div>'
        );
        }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/raisazka/Documents/laravel-project/idea-competition/resources/views/auth/register.blade.php ENDPATH**/ ?>