<?php $__env->startSection('content'); ?>
<div class="container">
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><strong>Admin's</strong> Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">No</th>
                            <th scope="col">Group Name</th>
                            <th scope="col">Payment</th>
                            <th scope="col">Verify</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td>
                                <a href="<?php echo e(asset('storage/payment/'.$user->payments->payment)); ?>">
                                    <img src="<?php echo e(asset('storage/payment/'.$user->payments->payment)); ?>" alt="no-image" height="100" width="200">
                                </a>
                            </td>
                            <td>
                            <form action="<?php echo e(route('admin.verify', $user->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="btn btn-success"<?php echo e($user->payments->status == 'Verified' ? 'disabled':''); ?>>Verify</button>
                            </form>
                            </td>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
    <a href="<?php echo e(route('admin.dashboard')); ?>">View User Payment</a>
    <br>
    <a href="<?php echo e(route('admin.member')); ?>">View Members</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/raisazka/Documents/laravel-project/idea-competition/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>